/*
 * CheckerMove.cpp
 *
 *  Created on: Aug 2, 2021
 *      Author: theresesmith
 */

#include "CheckerMove.h"

CheckerMove::CheckerMove() {
	// TODO Auto-generated constructor stub

}

CheckerMove::~CheckerMove() {
	// TODO Auto-generated destructor stub
}

